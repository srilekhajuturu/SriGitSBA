﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCF_project
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CustomerService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select CustomerService.svc or CustomerService.svc.cs at the Solution Explorer and start debugging.
    public class CustomerService : ICustomerService
    {
        public void Add(SUPPLIER sUPPLIER)
        {
            PODbEntities objctx = new PODbEntities();
            objctx.SUPPLIERs.Add(sUPPLIER);
            objctx.SaveChanges();

        }

        public void DeleteSUPPLIER(string suplno)
        {
            
                PODbEntities objctx = new PODbEntities();
                var data1 = (from c in objctx.SUPPLIERs
                             where c.SUPLNO == suplno
                             select c).FirstOrDefault();
                objctx.SUPPLIERs.Remove(data1);
                objctx.SaveChanges();


           
            
        }

        

        public SUPPLIER GetSUPPLIER()
        {
            PODbEntities objctx = new PODbEntities();
            var data = (from n in objctx.SUPPLIERs
                       select n).FirstOrDefault();
            return data;





        }

        public List<SUPPLIER> GetSUPPLIERs()
        {
            PODbEntities objctx = new PODbEntities();
            var data = from n in objctx.SUPPLIERs
                       select n;
            return data.ToList();


        }

        public void UpdateSUPPLIER(SUPPLIER sUPPLIER)
        {
            PODbEntities objctx = new PODbEntities();
            var data1 = (from c in objctx.SUPPLIERs
                         where c.SUPLNO == sUPPLIER.SUPLNO
                         select c).FirstOrDefault();
            data1.SUPLADDR = sUPPLIER.SUPLADDR;
            data1.SUPLNAME = sUPPLIER.SUPLNAME;
            data1.SUPLNO = sUPPLIER.SUPLNO;


            
            objctx.SaveChanges();
        }
    }
}
