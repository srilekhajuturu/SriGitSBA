﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCF_project
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "Icust" in both code and config file together.
    [ServiceContract]
    public interface Icust
    {
        [OperationContract]
        List<POMASTER> GetPOMASTERs();
        [OperationContract]
        POMASTER GetPOMASTER();
        [OperationContract]
        void Add(POMASTER pOMASTER);
        [OperationContract]
        void DeleteSUPPLIER(int id);
        [OperationContract]
        void UpdatePOMASTER(POMASTER pOMASTER);
    }
}
