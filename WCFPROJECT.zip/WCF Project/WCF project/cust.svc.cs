﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCF_project
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "cust" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select cust.svc or cust.svc.cs at the Solution Explorer and start debugging.
    public class cust : Icust
    {
        public void Add(POMASTER pOMASTER)
        {
            PODbEntities objctx = new PODbEntities();
            objctx.POMASTERs.Add(pOMASTER);
            objctx.SaveChanges();
        }

        public void DeleteSUPPLIER(int suplno)
        {
            PODbEntities objctx = new PODbEntities();
            var data1 = (from c in objctx.POMASTERs
                         where c.SUPLNO.ToString() == suplno.ToString()
                         select c).FirstOrDefault();
            objctx.POMASTERs.Remove(data1);
            objctx.SaveChanges();
        }

        public POMASTER GetPOMASTER()
        {
            PODbEntities objctx = new PODbEntities();
            var data = (from n in objctx.POMASTERs
                        select n).FirstOrDefault();
            return data;
        }

        public List<POMASTER> GetPOMASTERs()
        {
            PODbEntities objctx = new PODbEntities();
            var data = from n in objctx.POMASTERs
                       select n;
            return data.ToList();
        }

        public void UpdatePOMASTER(POMASTER pOMASTER)
        {
            PODbEntities objctx = new PODbEntities();
            var data1 = (from c in objctx.POMASTERs
                         where c.SUPLNO == pOMASTER.SUPLNO
                         select c).FirstOrDefault();
            data1.PODATE = pOMASTER.PODATE;
            data1.PONO = pOMASTER.PONO;
            data1.SUPLNO = pOMASTER.SUPLNO;
        }
    }
}
